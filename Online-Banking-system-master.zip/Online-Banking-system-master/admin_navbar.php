<div class='admin_nav'>
               <ul>
                   <li id='caption'><b><u>Admin</u></b></li>
                   
                   <li><a href="admin_hompage.php">Admin Home</a></li>
                   <li><a href="change_password.php">Change password</a></li>
                 
                   <li><a href="admin_logout.php">Logout</a></li>
                   </ul>
               </div>