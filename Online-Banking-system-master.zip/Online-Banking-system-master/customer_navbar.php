<div class='customer_nav'>
               <ul>
                   <li id='caption'><b><u>Accounts</u></b></li>
                   
                   
                   <li><a href="customer_account_summary.php">Accounts summary</a></li>
                   <li><a href="customer_mini_statement.php">Mini statement</a></li>
                   
                   <li><a href="customer_account_statement.php">Account statement</a></li>
                 </ul>
                
        
    <ul>
                    <li id='caption'><b><u>Fund Transfer</u></b></li>
                    <li><a href="add_beneficiary.php">Add Beneficiary</a></li>
                    <li><a href="display_beneficiary.php">View added Beneficiary</a></li>
                    <li><a href="customer_transfer.php">Transfer Funds</a></li>
                   
                   </ul>
    <ul>
        <li id='caption'><b><u>Requests</u></b></li>
        <li><a href="customer_issue_atm.php">Issue ATM card/Cheque book</a></li>
        
                    </ul>
    
    <ul>
        <li id='caption'><b><u>Profile</u></b></li>
        
        <li><a href="customer_personal_details.php">Personal Details</a></li>
        <li><a href="change_password_customer.php">Change Password</a></li>
        <li><a href="customer_logout.php">Logout</a></li>
                    </ul>
    
    
               </div>