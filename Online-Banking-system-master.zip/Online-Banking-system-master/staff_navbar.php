<div class='customer_nav'>
               <ul>
                   <li id='caption'><b><u>Staff</u></b></li>
                   
                   <li><a href="staff_homepage.php">Staff Home</a></li>
                   <li><a href="staff_beneficiary.php">Beneficiary Requests</a></li>
                   <li><a href="staff_atm_approve.php">ATM approval Requests</a></li>
                   <li><a href="staff_cheque_approve.php">Cheque Book approval Requests</a></li>
                 </ul>
                
        
   <ul>
        <li id='caption'><b><u>Profile</u></b></li>
        
        <li><a href="change_password_staff.php">Change password</a></li>
        <li><a href="staff_logout.php">Logout</a></li>
                    </ul>
    
    
               </div>