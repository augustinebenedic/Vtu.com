<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Contact Us</title>
        
        <link rel="stylesheet" href="newcss.css">
        <style>
            .heading{
    font-weight:bold;
    color:#2E4372;
}
        </style>
       
    </head>
        <?php include 'header.php' ?>
        <div class='content_customer'>
            <h3 style="text-align:center;color:#2E4372;"><u>Contact Us</u></h3>
            
            <div class="contact">
            <h3 style="color:#2E4372;"><u>Kolkata Branch</u></h3>
            <p><span class="heading">Address - </span>Globsyn Buisness School, IBRAD buisness school, Keshtopur, Kolkata.</p>
            <p><span class="heading">Tel - </span>033-456892/12</p>
            <p><span class="heading">Email - </span>kolkatabranch@onlinebank.com</p>
            
             <h3 style="color:#2E4372;"><u>Delhi Branch</u></h3>
            <p><span class="heading">Address - </span>Globsyn Buisness School, Sector V-A , Malviya Nagar, Delhi.</p>
            <p><span class="heading">Tel - </span>013-456856/32</p>
            <p><span class="heading">Email - </span>delhibranch@onlinebank.com</p>
            
             <h3 style="color:#2E4372;"><u>Bangalore Branch</u></h3>
            <p><span class="heading">Address - </span>Globsyn Buisness School, Near City Center, Kamarthalli, Bangalore.</p>
            <p><span class="heading">Tel - </span>022-456854/11</p>
            <p><span class="heading">Email - </span>bangalorebranch@onlinebank.com</p>
            </div>
            </div>